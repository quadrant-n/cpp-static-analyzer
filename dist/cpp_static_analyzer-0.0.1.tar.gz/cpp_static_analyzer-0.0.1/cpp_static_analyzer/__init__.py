import cpp_static_analyzer.main as csa_main

if __name__ == "__main__":
    csa_main.main()
