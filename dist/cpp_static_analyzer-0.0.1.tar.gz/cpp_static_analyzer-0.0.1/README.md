# C/CPP Static Analyzer

Execute clang-tidy using compile_commands.json. Can be used with compile_commands.json generated
from other platform such as Windows.

**Warning:** This tool is under development and not yet ready for production.
